# Flying Free v2 — validación del rediseño

29 de octubre de 2026. Unity Editor **6000.6.3f1**, Windows, uGUI **2.0.0**.

## Cambio visual

- Se ha incorporado el PNG original del logo, sin cambiar sus píxeles ni su transparencia. Su SHA-256 coincide con el archivo aportado: `A20371AFBA87C84CEFA0D06F8C5471AF79EB276044F253F9398A67858C1ECF34`.
- El fondo plano de la primera versión se sustituye por dos fondos de parque con profundidad, luz, sombras, farolas, bancos y ciudad al fondo, siguiendo la referencia del usuario. Hay un encuadre horizontal y otro vertical, con recorte proporcional.
- Los botones tienen sprites transparentes independientes con textura, bisel, contorno oscuro y relieve. Sus iconos y textos son controles/elementos de Unity independientes del fondo. Se conserva exactamente JUGAR, CONFIGURACIÓN y SALIR en la página principal.
- La tipografía de la interfaz es Kalam Bold, con su licencia SIL OFL incluida.
- El panel de configuración utiliza el mismo estilo manuscrito y papel crema, con volumen de sonido, música, silencio y regreso al menú.

## Pruebas

La escena y el prefab se han generado con el Editor de Unity. Los scripts compilan. Se han comprobado en Play Mode:

- Presencia de ambas texturas de fondo, logo e iconos independientes; sprites con bordes para nine-slicing.
- EventSystem automático y tres botones principales.
- Eventos JUGAR/SALIR mediante PointerClick, apertura/cierre de configuración.
- Sliders de sonido/música, silencio y recuperación de volúmenes.
- Guardado y restauración de ajustes al recrear el prefab.
- Fondos correctos para cada orientación, controles dentro de safe area simulada y textos dentro de sus cajas.

Capturas renderizadas por Unity en `Previews-v2`:

| Archivo | Resolución |
| --- | --- |
| 01-menu-vertical.png | 1080 × 1920 |
| 02-menu-horizontal.png | 1920 × 1080 |
| 03-configuracion-vertical.png | 1080 × 1920 |
| 04-configuracion-horizontal.png | 1920 × 1080 |
| 05-tablet.png | 1536 × 2048 |
| 06-movil-compacto.png | 1280 × 720 |

El detalle de cada comprobación se guarda en `Previews-v2/verification.txt`. Para guardar las capturas, el verificador cambia temporalmente el Canvas a Screen Space Camera; la escena y el prefab entregados siguen usando Screen Space Overlay. Se inyectan tamaños y zonas seguras simuladas en el cálculo de layout real.

## Integración y límites

No se ha probado en un móvil físico ni con una sesión de RA, audio real o la rama de Input System. No se ha ejecutado Application.Quit durante la prueba. JUGAR conserva su UnityEvent para enlazar la lógica del compañero. No hay juego ni pistas de audio incluidos. La versión de salida forzada sigue limitada a Android/escritorio; en iOS y WebGL se emite el evento para que el proyecto gestione esa acción.

Durante el arranque de este Editor aparece una excepción propia del índice de búsqueda SearchDatabase; las pruebas de UI terminan después con éxito. No se afirma que toda la sesión del Editor esté libre de errores.

Los cuatro assets de fondo/botones se generaron con la herramienta integrada `image_gen`. Los prompts completos y la procedencia están en `Assets/FlyingFree/UI/Art/V2/Generation.json`. El logo es el archivo original del usuario.
