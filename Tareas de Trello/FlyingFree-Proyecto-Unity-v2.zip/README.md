# Flying Free — proyecto de menú Unity · versión 2

Abre esta carpeta con Unity Hub usando Unity **6000.6.3f1**.

Escena: `Assets/FlyingFree/UI/Scenes/FlyingFreeMenu.unity`.

Prefab: `Assets/FlyingFree/UI/Prefabs/FlyingFreeMenu.prefab`.

La guía completa de importación, funcionamiento, eventos e integración está en [Assets/FlyingFree/UI/README.md](Assets/FlyingFree/UI/README.md).

Esta revisión incorpora el logo original aportado, fondos de parque para vertical/horizontal y botones con textura, bisel, iconos y tipografía Kalam Bold. El código y los controles de UI siguen siendo editables y los eventos están disponibles para conectar el juego.

Las dependencias de Unity UI se declaran en `Packages/manifest.json`. No se requiere ningún paquete de RA para ejecutar el menú. El compañero que desarrolla el juego debe conectar el evento On Play Requested a su propia lógica.
